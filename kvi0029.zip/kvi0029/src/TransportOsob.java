public interface TransportOsob {
  void transportuj();
}
